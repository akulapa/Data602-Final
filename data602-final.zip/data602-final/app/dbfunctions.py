#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 29 2017

@authors: Ilya Kats, Nnaemezue Obi-Eyisi Pavan Akula
"""

from app import app, db
from .models import Team, Player, Country, League, Team_Attributes, Player_Attributes, Match
import pandas as pd
import datetime
import time
from sqlalchemy import func, desc
from sqlalchemy.sql.expression import label
import numpy as np
from dateutil.relativedelta import relativedelta
from sklearn import preprocessing, cross_validation, svm
from sklearn.linear_model import LinearRegression

def get_teams():
    
    result = db.session.query(Team).all()
    df = pd.DataFrame()
    for row in result:
        data = {'Team ID': row.team_short_name, 'Team': row.team_long_name}
        df = df.append(data, ignore_index=True)
    return df

def get_leagues():
    result = League.query.with_entities(League.name, League.id).distinct()
    df = pd.DataFrame()
    for row in result:
        data = {'League': row.name,'LeagueId':'L' + str(row.id)}
        df = df.append(data, ignore_index=True)
    return df

def get_seasons():
    result = Match.query.with_entities(Match.league_id, Match.season).distinct()
    df = pd.DataFrame()
    for row in result:
        data = {'LeagueId':'L' + str(row.league_id), 'Season': row.season, 'SeasonId': str(row.season).replace('/','-')}
        df = df.append(data, ignore_index=True)
    if df.shape[0]>0:
        df = df.sort_values(by='Season', ascending=False)
    return df

def get_leauge_teams():
    result1 = Match.query.with_entities(Match.league_id, Match.season, label('team_api_id',Match.home_team_api_id))
    result2 = Match.query.with_entities(Match.league_id, Match.season, label('team_api_id',Match.away_team_api_id))
    result = result1.union(result2)
    
    df = pd.DataFrame()
    for row in result:
        teams = db.session.query(Team).filter(Team.team_api_id == row.team_api_id).all()
        for team in teams:
            data = {'LeagueId':'L' + str(row.league_id), 'Season':row.season, 'Team Id': team.team_short_name, 'Team Name': team.team_long_name}
            df = df.append(data, ignore_index=True)
    if df.shape[0]>0:
        df = df.sort_values(by='Season', ascending=False)
    return df