#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 29 2017

@authors: Ilya Kats, Nnaemezue Obi-Eyisi Pavan Akula
"""

from flask import render_template, make_response, flash, request
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
plt.switch_backend('agg')
import matplotlib.dates as mdates #import DateFormatter
from io import BytesIO
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.finance import candlestick_ohlc
import matplotlib.ticker as mticker
import matplotlib.mlab as mlab
from scipy.stats import norm
from app import app

from .dbfunctions import get_teams, get_leagues, get_leauge_teams, get_seasons

@app.route('/', methods=['GET', 'POST'])
@app.route('/home', methods=['GET', 'POST'])
def home():
    leaugeTable = get_leagues()
    leaugeTeams = get_leauge_teams()
    leaugeSeasons = get_seasons()
    print(leaugeTable)
    return render_template('home.html', 
                           leaugeTable=leaugeTable, 
                           leaugeTeams=leaugeTeams,
                           leaugeSeasons = leaugeSeasons,
                           home = 'class=active data-toggle=pill', 
                           team='', 
                           game='')


